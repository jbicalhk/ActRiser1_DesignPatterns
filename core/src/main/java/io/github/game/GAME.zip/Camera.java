package io.github.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class Camera {
    private OrthographicCamera camera;
    
    
    public void createCamera() {
        camera = new OrthographicCamera();      
        camera.setToOrtho(false, Gdx.graphics.getWidth() / 2f, Gdx.graphics.getHeight() / 2f);
 //NUNCA TIRAR ISSO DAQUI
    }

    public void updateCamera(Player player) {
    	camera.position.set(player.getX() + player.rect.width / 2, player.getY() + player.rect.height / 2, 0);
    	camera.update();      
    }

    public OrthographicCamera getCamera() {
        return camera;
    }
}
