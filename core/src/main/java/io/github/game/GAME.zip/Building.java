package io.github.game;

public class Building extends Map {
	

	public Building(String mapFilePath) {
		super(mapFilePath);
		// TODO Auto-generated constructor stub
	}

	public void render() {
		System.out.println("Renderizando construção");
	}
}
