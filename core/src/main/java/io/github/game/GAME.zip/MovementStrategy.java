package io.github.game;

public interface MovementStrategy {
	void move(float deltaTime, Player player);
}
