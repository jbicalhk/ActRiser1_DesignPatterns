package io.github.game;

interface Observer {
	void update(String event, Object data);
}
